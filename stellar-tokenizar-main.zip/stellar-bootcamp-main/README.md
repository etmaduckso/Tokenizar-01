# Stellar Bootcamp

## Aula 1

- O que é DeFi? O que é economia tokenizada?
- O que são tokens, Assets e criptomoedas?
- Como funcinoa a web3? como a Stellar se encaixa?
- Tokeneconomics Stellar, principais DeFi.
- Blockchain low-level: wallet, tx, blocks, consenso, smartcontracts

## Aula 2

- Fundamentos sobre Stellar.
- Configurando fullnode e DevOps
- Interagindo com o fullnode usando SDK.

## Aula 3

- Ecosistema de sistema de desenvolvimento Rust
- Básico sobre Rust
- Básico de smartcontrats Soroban (Hello World)

## Aula 4

- Flipando bits (Flipper)
- Entendo sobre armazenamento (Counter)
- Avançando em lógica (Task manager)

## Aula 5

- Noções avançadas de Soroban
